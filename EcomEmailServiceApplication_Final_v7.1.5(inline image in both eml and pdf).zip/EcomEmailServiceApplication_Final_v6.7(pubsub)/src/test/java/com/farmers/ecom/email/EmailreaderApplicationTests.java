package com.farmers.ecom.email;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomEmailServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
